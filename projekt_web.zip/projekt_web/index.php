<!doctype html>
<html lang="hr">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8">
		<meta name="description" content="site">
		<meta name="keywords" content="site">
		<meta name="author" content="Ante Šterle">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Home</title>
		<link rel="shortcut icon" type="image/png" href="images/favico.png">
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>	
	<header>
		<div class="navigation">
		<a href="index.php"><img src="images/banner.png" width="1000px" alt="Banner"></a>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="news.php">News</a></li>
				<li><a href="contact.php">Contact</a></li>
				<li><a href="tourism.php">Tourism</a></li>
				<li><a href="gallery.php">Gallery</a></li>
			</ul>
		</nav>
		</div>
	</header>	
	<main>
			<div class="prvo">
			<h1>Grad Sisak</h1>
			<figure>
				<img src="images/sisak panorama.png" alt="Panorama grada" width="680" height="403">
			</figure>
			<p>Sisak (Croatian: [sǐːsak]) is a city and episcopal see in central Croatia, located at the confluence of the Kupa, Sava and Odra rivers, 57 km southeast of the Croatian capital Zagreb, and is usually considered to be where the Posavina (Sava basin) begins, with an elevation of 99 m. The city's total population in 2011 was 47,768. Sisak is the administrative centre of the Sisak-Moslavina County, Croatia's biggest river port and a centre of river shipping industry. It lies on the main road Zagreb-Sisak-Petrinja and the railroad Zagreb-Sisak-Sunja. Sisak is a regional economic, cultural and historical center. The largest oil refinery in Croatia is located here.</p>
			<h4>History</h4>
			<p>Siscia is described by Roman writers as a great town in the south of Upper Pannonia, on the southern bank of the Savus, on an island formed by that river and two others, the Colapis and Odra, a canal dug by Tiberius completing the island. It was situated on the great road from Aemona to Sirmium. According to Pliny the name Segestica belonged only to the island, and the town was called Siscia; while Strabo says that Siscia was a fort in the neighbourhood of Segestica; but if this was so, it must be supposed that subsequently the fort and town became united as one place. Siscia was from the first a strongly fortified town; and after its capture by Tiberius, in the reign of Augustus, it became one of the most important places of Pannonia; for being situated on two navigable rivers, it not only carried on considerable commerce, but became the central point from which Augustus and Tiberius carried on their undertakings against the Pannonians and Illyrians. Tiberius did much to enlarge and embellish the town, which as early as that time seems to have been made a colonia, for Pliny mentions it as such: in the time of Septimius Severus it received fresh colonists, whence in inscriptions it is called Col. Septimia Siscia. The town contained an imperial mint, which produced coins under a series of emperors between 262 and 383 AD. The Christian martyr Quirinus of Sescia, presumed the first bishop of the Diocese of Sescia, was tortured and nearly killed during Diocletian's persecution of Christians. Legend has it that they tied him to a millstone and threw him into a river, but he freed himself from the weight, escaped and continued to preach his faith. Today he is the patron saint of Sisak. When Diocletian split Pannonia into four provinces, Siscia became the capital of Pannonia Savia, the southwestern one, for which Siscia contained the treasury; at the same time it was the station of the small fleet kept on the Savus. Siscia maintained its importance until Sirmium began to rise, for in proportion as Sirmium rose, Siscia sank and declined.</p>
			<p>The Battle of Sisak (Croatian: Bitka kod Siska) was fought on 22 June 1593 between Ottoman regional forces of Telli Hasan Pasha, a notable commander (Beglerbeg) of the Eyalet of Bosnia, and a combined Christian army from the Habsburg lands, mainly Kingdom of Croatia and Inner Austria. The battle took place at Sisak, central Croatia, at the confluence of the rivers Sava and Kupa. Earlier in 1591 and 1592 the Ottomans had two failed attempts of capturing the Sisak fortress, but managed to take the strategically important fortress of Bihać in 1592. The Sisak fortress was again besieged by a large Ottoman force on 15 June 1593. The garrison in Sisak was commanded by Blaž Đurak and Matija Fintić, both from the Diocese of Zagreb. An army under the supreme command of the Styrian general Ruprecht von Eggenberg was quickly assembled to break the siege. The Croatian troops were led by the Ban of Croatia, Thomas Erdődy, and major forces from the Duchy of Carniola and the Duchy of Carinthia were led by Andreas von Auersperg, nicknamed the "Carniolan Achilles". They made a surprise attack on the besieging forces on 22 June. The ensuing battle resulted in a crushing defeat for the regional Ottoman forces, triggering the Long War.</p>
			<figure>
				<img src="images/stari grad.png" alt="Stari grad" width="500" height="281">
				<figcaption>Fort Old town</figcaption>
			</figure>
			<p>In the late 19th and early 20th century, Sisak was a district capital in the Zagreb County of the Kingdom of Croatia-Slavonia.</p>
			<p>From 1929-39, Sisak was part of the Sava Banovina and from 1939-41 of the Banovina of Croatia within the Kingdom of Yugoslavia. During World War II, first Partisan unit was founded in forest Brezovica near Sisak. During Yugoslavia Sisak became biggest industrial city in SR Croatia and one of the biggest in Yugoslavia. Some of the major factories were ferrous metallurgy (iron works), chemicals, leather (footwear), textiles and food processing plants (dairy products, alcoholic beverages), building material, crude oil refinery and thermal power. With the outbreak of the Croatian War in 1991, Sisak remained in Government hands while the territory to the south was controlled by rebelled Serbs. During the war, the Serb forces often shelled the city, causing dozens of civilian casualties and extensive damage to the city's industry. The war ended with the Operation Storm (1995).</p>
			<p>Today most of industry in Sisak is gone. But it offers a lot of destinations for sightseeing.</p>
			</div>
	</main>
		<div class="footer">
		<footer><p>Copyright &copy; 2019 Ante Šterle.</p> 
		</footer>
		</div>
	</body>
</html>