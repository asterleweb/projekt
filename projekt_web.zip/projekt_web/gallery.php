<!doctype html>
<html lang="hr">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8">
		<meta name="description" content="site">
		<meta name="keywords" content="site">
		<meta name="author" content="Ante Šterle">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Gallery</title>
		<link rel="shortcut icon" type="image/png" href="images/favico.png">
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	<header>
		<div class="navigation">
		<a href="index.php"><img src="images/banner.png" alt="Banner"></a>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="news.php">News</a></li>
				<li><a href="contact.php">Contact</a></li>
				<li><a href="tourism.php">Tourism</a></li>
				<li><a href="gallery.php">Gallery</a></li>
			</ul>
		</nav>
		</div>
	</header>
	</body>
	<main>
	<div class="gallery" >
		<h2>Gallery</h2>
		<figure>
		<a href="gallery/holandska kuća.png" alt="" target="_blank"><img src="gallery/holandska kuća.png" width="350" height="257"></a>
		<figcaption>Holandska kuća (Dutch house)</figcaption>
		</figure>
		<figure>
		<a href="gallery/iskopine.png" alt="" target="_blank"><img src="gallery/iskopine.png" width="350" height="257"></a>
		<figcaption>Iskopine Siscie (Excavations of Siscia)</figcaption>
		</figure>
		<figure>
		<a href="gallery/stari grad1.png" alt="" target="_blank"><img src="gallery/stari grad1.png" width="350" height="257"></a>
		<figcaption>Stari grad (Old town)</figcaption>
		</figure>
		<figure>
		<a href="gallery/stari most.png" alt="" target="_blank"><img src="gallery/stari most.png" width="350" height="257"></a>
		<figcaption>Stari most (Old bridge)</figcaption>
		</figure>
		<figure>
		<a href="gallery/šetnica.png" alt="" target="_blank"><img src="gallery/šetnica.png" width="350" height="257"></a>
		<figcaption>Šetnica (Walking trail)</figcaption>
		</figure>
	</div>
	</main>
	<div class="footer">
	<footer><p>Copyright &copy; 2019 Ante Šterle.</p> 
	</footer>
	</div>
</html>