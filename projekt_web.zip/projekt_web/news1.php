<!doctype html>
<html lang="hr">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8">
		<meta name="description" content="site">
		<meta name="keywords" content="site">
		<meta name="author" content="Ante Šterle">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Museum night</title>
		<link rel="shortcut icon" type="image/png" href="images/favico.png">
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	<header>
		<div class="navigation">
		<a href="index.php"><img src="images/banner.png" alt="Banner"></a>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="news.php">News</a></li>
				<li><a href="contact.php">Contact</a></li>
				<li><a href="tourism.php">Tourism</a></li>
				<li><a href="gallery.php">Gallery</a></li>
			</ul>
		</nav>
		</div>
	</header>
	<main>
		<div class="news1">
			<h1>Museum night in Sisak</h1>
			<figure>
				<img src="images/noc muzeja.png" alt="Museum night" width="450px" height="321px"></a>
			</figure>
			<p>Every year Croatian museum society organizes action called Museum night. On that ocasion museums, gallerys and other coultural institutions open their doors for all visitors from 18:00 to 01:00 hours, for free and with apposite program.</p>
			<p>Traditionally, City Museum Sisak will take part in this manifestation.Theme for the Museum night this year will be "Museums - inovations and digital future" so our city museum prepared dynamic and fun program for people of all ages.</p>
			<p>Museum night will be held on Friday, 1st of February 2019., u Ulica kralja Tomislava 10, 44000 Sisak from 18:00 h.</p>
			<h3>Program</h3>
			<p>18:00 - 01:00 h - Presentation of projects related to inovations and digital technology.</p>
			<p>20:00 h - Presentation of monograph "110 years of cinematography in Sisak."</p>
			<p>20:30 h - Concert of film mucisc (Music school Fran Lhotka Sisak)</p>
			<p>21:15 h - Presentation of cultural and historical heritage through modern technology.</p>
			<p>18:00 - 22:00 h - Educative program for youngest visitors.</p>
			<br>
			<p>Source:<a href="http://www.sisak.info/i-sisacki-muzej-obiljezit-ce-noc-muzeja/" target="_blank">www.sisak.info</a></p>
			<a href="News.php"><h4>Back to News</h4></a>
		</div>
	</main>
	<div class="footer">
	<footer><p>Copyright &copy; 2019 Ante Šterle.</p> 
	</footer>
	</div>
	</body>
</html>