<!doctype html>
<html lang="hr">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8">
		<meta name="description" content="site">
		<meta name="keywords" content="site">
		<meta name="author" content="Ante Šterle">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Sisak</title>
		<link rel="shortcut icon" type="image/png" href="images/favico.png">
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	<header>
		<div class="navigation">
		<a href="index.php"><img src="images/banner.png" alt="Banner"></a>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="news.php">News</a></li>
				<li><a href="contact.php">Contact</a></li>
				<li><a href="tourism.php">Tourism</a></li>
				<li><a href="gallery.php">Gallery</a></li>
			</ul>
		</nav>
		</div>
	</header>
	<main>
		<div class="news2">
			<h1>Vlatko Štampar performing in Sisak</h1>
			<figure>
				<img src="images/vlatko stampar.png" alt="Vlatko Štampar" width="500" height="500"></a>
			</figure>
			<p>After sold out standup shows all across Croatia, famous comedian Vlatko Štampar premier performance on Thursday, 31st of January 2019., from 20 o'clock  in Dom kulture in Sisak.</p>
			<p>The fans of his humor will love his new show where he in his unique way answers the question about relation of good and evil, material and spiritual and differnece in our behavior when we are alone and when we are with others.</p>
			<p>Bratec je trd, Štamparska greška, Odraslost are some of his shows with which he had big success all over the Croatia and the rest of the region.</p>
			<br>
			<p>Source:<a href="http://www.sisak.info/popularni-komicar-vlatko-stampar-s-boljom-polovicom-nastupa-u-sisku/" target="_blank">www.sisak.info</a></p>
			<a href="news.php"><h4>Back to News</h4></a>
		</div>
	</main>
	<div class="footer">
	<footer><p>Copyright &copy; 2019 Ante Šterle.</p> 
	</footer>
	</div>
	</body>
</html>