<!doctype html>
<html lang="hr">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8">
		<meta name="description" content="site">
		<meta name="keywords" content="site">
		<meta name="author" content="Ante Šterle">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Contact</title>
		<link rel="shortcut icon" type="image/png" href="images/favico.png">
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	<header>
		<div class="navigation">
		<a href="index.php"><img src="images/banner.png" alt="Banner"></a>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="news.php">News</a></li>
				<li><a href="contact.php">Contact</a></li>
				<li><a href="tourism.php">Tourism</a></li>
				<li><a href="gallery.php">Gallery</a></li>
			</ul>
		</nav>
		</div>
	</header>
	</body>
	<main>
	<div class="frame">
		<h1> Map and contact</h1>
		<p>email: asterle@vvg.hr</p>
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d44764.21699443632!2d16.355701647334026!3d45.47456659973518!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4766e5306f2ca433%3A0x400ad50862bbab0!2sSisak!5e0!3m2!1sen!2shr!4v1548776097475" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
	</div>

	</main>
	<div class="footer">
	<footer><p>Copyright &copy; 2019 Ante Šterle.</p> 
	</footer>
	</div>
</html>