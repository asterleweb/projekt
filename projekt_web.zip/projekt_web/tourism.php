<!doctype html>
<html lang="hr">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8">
		<meta name="description" content="site">
		<meta name="keywords" content="site">
		<meta name="author" content="Ante Šterle">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Help for tourists</title>
		<link rel="shortcut icon" type="image/png" href="images/favico.png">
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	<header>
		<div class="navigation">
		<a href="index.php"><img src="images/banner.png" alt="Banner"></a>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="news.php">News</a></li>
				<li><a href="contact.php">Contact</a></li>
				<li><a href="tourism.php">Tourism</a></li>
				<li><a href="gallery.php">Gallery</a></li>
			</ul>
		</nav>
		</div>
	</header>
	<main>
		<div class="form">
		<form action="" method="get">
		<span>Enter value in HRK :</span> <input type="text" name="input"/>
		<span>Select Currency :</span> 
		<select name="dropdown">
		<option value="usd">Us Dollar</option>
		<option value="ero">Euro</option>
		<option value="gbp">British Pound</option>
		</select>
		<input type="submit" name="sbmt" value="Convert" />
		</form>
		</div>
		<div class="out">
		<?php

		 if(isset($_GET['sbmt']))
		 {
		  $_input = $_GET['input'];
		  $_dropdown = $_GET['dropdown'];
		  
		  if($_dropdown == 'usd')
		  {
		   $output = $_input * 0.15;
		   echo "<h1>" . number_format($output,2) . " Dollar" . "</h1>";
		  }
		  else if($_dropdown == 'ero')
		  {
		   $output = $_input * 0.13;
		   echo "<h1>" . number_format($output,2) . " Euro" . "</h1>";
		  }
		  else if($_dropdown == 'gbp')
		  {
		   $output = $_input * 0.12;
		   echo "<h1>" . number_format($output,2) . " British Pound" . "</h1>"; 
		  }
		 }
		 // source code: https://www.youtube.com/watch?v=ht6jphIekZw, kod je odgovoru na zadnji komentar
		 ?>
		</div>
		<div class="disclamer">
		<p>Disclamer. Conversion rates from 29.1.2019. Also values are rough</p>
		</div>
	</main>
	<div class="footer">
	<footer><p>Copyright &copy; 2019 Ante Šterle.</p> 
	</footer>
	</div>
	</body>
</html>