<!doctype html>
<html lang="hr">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8">
		<meta name="description" content="site">
		<meta name="keywords" content="site">
		<meta name="author" content="Ante Šterle">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>News</title>
		<link rel="shortcut icon" type="image/png" href="images/favico.png">
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	<header>
		<div class="navigation">
		<a href="index.php"><img src="images/banner.png" alt="Banner"></a>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="news.php">News</a></li>
				<li><a href="contact.php">Contact</a></li>
				<li><a href="tourism.php">Tourism</a></li>
				<li><a href="gallery.php">Gallery</a></li>
			</ul>
		</nav>
		</div>
	</header>
	<main>
		<div class="news">
			<h1>News</h1>
			<a href="news1.php"><img src="images/noc muzeja.png" alt="Museum night"></a>
			<h2><a href="news1.php">Museum night in Sisak</a></h2>
			<p>Sisak museum participates in action called Musem night.</p>
			<p><time datetime="29-1-2019"> 29 January 2019</time></p>
			<hr>
			
			<a href="news2.php"><img src="images/vlatko stampar.png" alt="Vlatko Štampar"></a>
			<h2><a href="news2.php">Vlatko Štampar performance.</a></h2>
			<p>Popular comedian Vlatko Štampar is performing his new show called Bolja polovica.</p>
			<p><time datetime="28-01-2019"> 28 January 2019</time></p>
		</div>
	</main>
	<div class="footer">
	<footer><p>Copyright &copy; 2019 Ante Šterle.</p> 
	</footer>
	</div>
	</body>
</html>